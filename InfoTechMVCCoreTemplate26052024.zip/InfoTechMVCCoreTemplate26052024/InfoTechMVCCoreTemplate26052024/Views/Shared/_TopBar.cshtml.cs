using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InfoTechMVCCoreTemplate26052024.Views.Shared
{
    public class _TopBarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
