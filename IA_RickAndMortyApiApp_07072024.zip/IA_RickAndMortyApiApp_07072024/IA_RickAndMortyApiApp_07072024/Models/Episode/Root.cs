﻿namespace IA_RickAndMortyApiApp_07072024.Models.Episode
{
    public class Root
    {
        public Info info { get; set; }
        public List<Result> results { get; set; }
    }
}
