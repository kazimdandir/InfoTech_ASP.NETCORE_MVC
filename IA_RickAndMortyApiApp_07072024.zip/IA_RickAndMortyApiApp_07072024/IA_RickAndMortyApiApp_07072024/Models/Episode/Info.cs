﻿namespace IA_RickAndMortyApiApp_07072024.Models.Episode
{
    public class Info
    {
        public int count { get; set; }
        public int pages { get; set; }
        public string next { get; set; }
        public object prev { get; set; }

        //ARAŞTIR "pagination" // sbadmin2'de örneği var 
    }
}
