﻿namespace InfoTechCoreMVCQuiz26052024.Models
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }
        public int ProductStockQuantity { get; set; }
    }
}
