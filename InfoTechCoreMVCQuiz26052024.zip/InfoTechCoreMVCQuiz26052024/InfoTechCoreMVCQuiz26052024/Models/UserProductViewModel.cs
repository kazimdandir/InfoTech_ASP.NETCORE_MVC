﻿namespace InfoTechCoreMVCQuiz26052024.Models
{
    public class UserProductViewModel
    {
        public List<UserClaim> Users { get; set; }
        public List<Product> Products { get; set; }
    }
}
