﻿using IA_Core_API_NTier.Entities;
using IA_Core_API_NTier.Repositories.Abstract;
using IA_Core_API_NTier.Services.Abstact;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IA_Core_API_NTier.Services.Concrete
{
    public class EmployeeManager : IEmployeeServices
    {
        public readonly IEmployeeRepository employeeRepository;

        public EmployeeManager(IEmployeeRepository EmployeeRepository)
        {
            this.employeeRepository = EmployeeRepository;
        }

        public Employee CreateEmployee(Employee employee)
        {
            if (employee is not null)
            {
                return employeeRepository.CreateEmployee(employee);
            }
            else
            {
                throw new Exception("Empoloyee null olamaz");
            }
        }

        public void DeleteEmployee(int employeeId)
        {
            if (employeeId != 0)
            {
                employeeRepository.DeleteEmployee(employeeId);
            }
            else
            {
                throw new Exception("ID Null olamaz");
            }
        }

        public List<Employee> GetEmployees()
        {
            return employeeRepository.GetEmployees();
        }

        public List<Employee> GetEmployeesByDepartment(string department)
        {
            if (department != null)
            {
                return employeeRepository.GetEmployeesByDepartment(department);
            }
            else
            {
                throw new Exception("Departman adi bos olamaz");
            }
        }

        public async Task<Employee> GetEmployeesById(int employeeId)
        {
            if (employeeId > 0)
            {
                return await employeeRepository.GetEmployeesById(employeeId);
            }
            else
            {
                throw new Exception("ID 1den kucuk olmaz");
            }
        }

        public Employee UpdateEmployee(Employee employee)
        {
            return employeeRepository.UpdateEmployee(employee);
        }
    }
}
