﻿using IA_Core_API_NTier.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IA_Core_API_NTier.Services.Abstact
{
    public interface IEmployeeServices
    {
        List<Employee> GetEmployees();
        Task<Employee> GetEmployeesById(int employeeId);
        List<Employee> GetEmployeesByDepartment(string department);

        Employee CreateEmployee(Employee employee);
        Employee UpdateEmployee(Employee employee);
        void DeleteEmployee(int employeeId);
    }
}
