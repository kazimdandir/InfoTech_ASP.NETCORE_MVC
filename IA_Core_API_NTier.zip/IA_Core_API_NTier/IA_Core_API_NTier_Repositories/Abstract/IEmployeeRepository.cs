﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IA_Core_API_NTier.Entities;

namespace IA_Core_API_NTier.Repositories.Abstract
{
    public interface IEmployeeRepository // not generic
    {
        List<Employee> GetEmployees();
        Task<Employee> GetEmployeesById(int employeeId);
        List<Employee> GetEmployeesByDepartment(string department);

        Employee CreateEmployee(Employee employee);
        Employee UpdateEmployee(Employee employee);
        void DeleteEmployee(int employeeId);
    }
}
