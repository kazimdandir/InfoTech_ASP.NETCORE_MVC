﻿using IA_Core_API_NTier.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IA_Core_API_NTier.Repositories.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext()
        {
            
        }

        public AppDbContext(DbContextOptions options):base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=DESKTOP-K3QEGEG\\SQLEXPRESS;Database=IA_Core_API_NTier_DB;Trusted_Connection=True;");
        }

        public virtual DbSet<Employee> Employees { get; set; }
    }
}
