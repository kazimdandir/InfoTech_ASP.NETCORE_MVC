﻿using IA_Core_API_NTier.Entities;
using IA_Core_API_NTier.Repositories.Abstract;
using IA_Core_API_NTier.Repositories.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IA_Core_API_NTier.Repositories.Concrete
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext context = new AppDbContext();

        public EmployeeRepository(AppDbContext Context)
        {
            this.context = Context;
        }

        public Employee CreateEmployee(Employee employee)
        {
            context.Employees.Add(employee);
            context.SaveChanges();
            return employee;
        }

        public void DeleteEmployee(int employeeId)
        {
            var employee = context.Employees.SingleOrDefault(x => x.Id == employeeId);
            context.Employees.Remove(employee);
            context.SaveChanges();
        }

        public List<Employee> GetEmployees()
        {
            return context.Employees.ToList();
        }

        public List<Employee> GetEmployeesByDepartment(string department)
        {
            var employeeList = context.Employees.Where(x => x.Department.ToLower().Contains(department.ToLower())).ToList();
            return employeeList;
        }

        public async Task<Employee> GetEmployeesById(int employeeId)
        {
            return await context.Employees.FindAsync(employeeId);
        }

        public Employee UpdateEmployee(Employee employee)
        {
            context.Employees.Update(employee);
            context.SaveChanges();
            return employee;
        }
    }
}
